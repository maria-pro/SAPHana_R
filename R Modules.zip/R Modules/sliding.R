dataT<-read.csv("dataset1.2016-09-10_1.csv")
#set date in date format
dataT$date=as.Date(dataT$date, format="%d/%m/%Y")

#some variables need to be lagged as months should read like this 01 May 2011 shows data for April 2011

##lag variables for +1 month: SVI, SVI_NEW, SVI_ASX, SVI_AU, 
library(DataCombine)
dataT<-slide(data, Var = "SVI", TimeVar="date", GroupVar = "code",  slideBy = -1)
dataT<-slide(data, Var = "SVI_NEW", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(data, Var = "SVI_ASX", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(data, Var = "SVI_AU", TimeVar="date", GroupVar = "code", slideBy = -1)

#lag variables for +1 month: PressAll, PressPapers, PressPapersMajor, PressPapersMinor, PressWires, PressWiresMajor, PressWiresMinor
dataT<-slide(dataT, Var = "PressAll", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressPapers", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressPapersMajor", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressPapersMinor", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressWires", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressWiresMajor", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "PressWiresMinor", TimeVar="date", GroupVar = "code", slideBy = -1)

#lag variables for +1 month: AnnOwn, AnnOwnSensitive
dataT<-slide(dataT, Var = "AnnOwn", TimeVar="date", GroupVar = "code", slideBy = -1)
dataT<-slide(dataT, Var = "AnnOwnSensitive", TimeVar="date", GroupVar = "code", slideBy = -1)

#lag sales for +1 year (12 months) to calculate sales growth = log(SalesY1/SalesY0)
dataT<-slide(dataT, Var = "Sales", TimeVar="date", GroupVar = "code", NewVar="sales_1Y", slideBy = -12)
#calculate sales growth
dataT$lsalesGrowth<-ifelse(dataT$Sales_1Y>0, log(data$Sales/dataT$Sales_1Y), NA)

write.csv(dataT, file="testing lag.csv")