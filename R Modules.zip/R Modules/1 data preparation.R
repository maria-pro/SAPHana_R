#TO BE DONE:calculate abnormal trading volume. Trading volume is calculated compared to last 8 months
#abnormal return - ? need to either recalculate F


#volume, value and transactions are at month end, NOSH is at the start of the month

#data from datastream is collected as at the 1 day of the month. which means that it is valid at the end of the previous month.
#1/07/2016 = 30/06/2016
#dates need to be treated with caution and possibly lagged one month to avoid confusion


##SalesGrowth needs to be fixed: 0 and NA to be imputed - done

#Sales to be imputed - done
#imputed NOSH is NOSH_N
#logs and other data transformation needs to be cleared


#install.packages("fBasics")
#install.packages("DMwR")
install.packages("corrr")  # package to do multiple correlations
install.packages ("DataCombine") #package to do lags in variables
install.packages ("dplyr")
install.packages("nloptr")
install.packages("plm")
install.packages ("data.table")
install.packages("quantmod")
install.packages("PerformanceAnalytics")
install.packages("reshape")


#library(DMwR) #local outlier factor algorithm for outliers identification
#library(fBasics) #Calculate basic stats for the sample and per each company
#library(lubridate) # to calculate years? but there should be an easier way for sure.
library(dplyr)
library(corrr)   # package to do multiple correlations
library(DataCombine)
library (nloptr)
library (plm)
library(data.table)  
library(xts)

#1.Substituting 0 for missing values where this can be done
#2. Lagging variables where needed =data
#3. Calculation of additional variables =data
#4. Cutting the dataset on low and upper bound <-assigning listing/delisting dates, calculating age = data2
#5. Winsorising = dataW
#6. Assigning industries, ASX100 and ASX200 listing
#7. MIssing values = dataR
#8. Log transformation = dataL


#remove all variables 
rm(list=ls(all=TRUE))

#data is the original dataset
#data2 is the dataset adjusted for company registration and for SVI, 2004-01-01
#dataW is the winsorised dataset - variables are replaced 
##(no new variables for winsorized data) except "date" and "code". industry variables and ASX100 and ASX200 are added later
#dataR is the dataset adjusted for missing data
#dataL is log transformed dataset
#dataF: module 2, is a copy of dataL with selected variables

#set working directory
setwd("C:\\Users\\masha\\Dropbox\\Visibility paper\\data\\final")

#functions
#Winsorising
#Winsorizing function: two tail: 1. Winzorise 2. Standardize: (x-mean)/std
winsor1 = function (x, fraction=.05)
{
  if(length(fraction) != 1 || fraction < 0 ||
     fraction > 0.5) {
    stop("bad value for 'fraction'")
  }
  lim <- quantile(x, probs=c(fraction, 1-fraction), na.rm=TRUE)
  x[ x < lim[1] ] <- lim[1]  # lower bound
  x[ x > lim[2] ] <- lim[2]  #upper bound
  x
}

#read data from the csv file
data<-read.csv("dataset1_2016-11-06.csv")
#set date in date format
data$date=as.Date(data$date, format="%d/%m/%Y")


#---------Abnormal trading volume calculations
#to merge the file with file with Volume/value data
#data are at the end of the month
#read data from the csv file
dataAdd<-read.csv("dataset1_asx_variables_2016-12-04.csv") #this is the file with volume/value/transaction data ONLY!
#set date in date format
dataAdd$date=as.Date(dataAdd$date, format="%d/%m/%Y")
#test<-merge(dataAdd, data[, c("date", "code", "NOSH"), by=c("date", "code"), all.x=TRUE])

test<-data.table(merge(dataAdd, data[, c("code", "date", "NOSH")], by=c("code", "date"), all.x=TRUE))
setkey(test, code, date)
#missing values in NOSH to be filled with prior/post observations
test[, NOSH_N:=test[!is.na(NOSH)][test, NOSH, roll=T]] #filled with prior months observations
test[, NOSH_N:=test[!is.na(NOSH_N)][test, NOSH_N, roll=-Inf]] #filled with next months observations
sum(is.na(test$NOSH_N)) #check if all NAs are filled

#calculate turnover as volume/NOSH
test$turnover<-test$volume/test$NOSH_N
sum(is.na(test$turnover))

#assign listing dates/delisting
listingDates<-read.csv("Listing dates.csv")
listingDates$Listed=as.Date(listingDates$Listed, format="%d/%m/%Y")
listingDates$Delisted=as.Date(listingDates$Delisted, format="%d/%m/%Y")
test<-merge(test, listingDates, by.x="code", by.y="Code")
test$isListed=0
test[(!is.na(test$Delisted) & test$date<test$Delisted & test$date>test$Listed),"isListed"]=1 #if listed within the period of listing date to delisting date
test[(is.na(test$Delisted) & test$date>test$Listed),"isListed"]=1 # if there is no delisted date, but data is after the listing date
rm(listingDates)
test<-test[isListed==1,]
sum(is.na(test$turnover))

#extract turnover and convert to xts
turnover<-as.xts.data.table(dcast(data = test,formula = date~code,fun.aggregate = sum,value.var = "turnover"))
volume<-as.xts.data.table(dcast(data = test,formula = date~code,fun.aggregate = sum,value.var = "volume"))
transactions<-as.xts.data.table(dcast(data = test,formula = date~code,fun.aggregate = sum,value.var = "transactions"))

#calculating moving average for each and abnormal values
aTurnover <- turnover/as.xts(rollapply(as.zoo(turnover), list(seq(-12,-1)), mean, na.rm=TRUE, by.column=TRUE, align="right", partial=TRUE))

aVolume<-volume/as.xts(rollapply(as.zoo(volume), list(seq(-12,-1)), mean, na.rm=TRUE, by.column=TRUE, align="right", partial=TRUE))
aTransactions<-transactions/as.xts(rollapply(as.zoo(transactions), list(seq(-12,-1)), mean, na.rm=TRUE, by.column=TRUE, align="right", partial=TRUE))

#merge to dataset
aTurnover <- as.data.table(aTurnover, keep.rownames=TRUE) 
aTurnover<- melt(aTurnover, id="index")  #converts vector into datatable into a vector: index, firm, turnover
colnames(aTurnover)<-c("date", "code", "aTurnover")

aVolume <- as.data.table(aVolume, keep.rownames=TRUE) 
aVolume<- melt(aVolume, id="index")  #converts vector into datatable into a vector: index, firm, volume
colnames(aVolume)<-c("date", "code", "aVolume")

aTransactions <- as.data.table(aTransactions, keep.rownames=TRUE) 
aTransactions<- melt(aTransactions, id="index")  #converts vector into datatable into a vector: index, firm, aTransactions
colnames(aTransactions)<-c("date", "code", "aTransactions")

write.csv(as.data.frame(aTurnover), file="aTurnover.csv", row.names=TRUE)
write.csv(as.data.frame(turnover), file="Turnover.csv", row.names=TRUE)


test<- Reduce(function(x, y) merge(x, y, by=c("code", "date"),  all=TRUE), list(aTurnover, aVolume, aTransactions, test))
test[,c("NOSH", "Listed", "Delisted", "isListed")]<-NULL
data<-merge(data, test, by=c("code","date"), all.x=TRUE)

#calculate alternative abnormal volume
#aTurnover <- turnover/rollapply(turnover, 8, mean, na.rm=TRUE)
#test<-as.data.frame(turnover, res)
#lapply(test, fun)

#wrong
#res<-function (x) 
#  {
#  lapply(
#      data = as.data.frame(x), 
#      function(x) {residuals(lm((x) ~ lag(x, k = -1) + lag(x, k = -2), na.rm=TRUE))}
#      )
#  }

#wrong
#aTurnover <- rollapply(turnover, width = 36, FUN=res(turnover), by.column = TRUE, align = "right")

#cannot get autoregression to calculate abn volume :((((
#testRoll<-rollapply(turnover, 3, mean, fill=NA, align="right", by.column=TRUE)
#testRoll<-rollapply(turnover[,3], 3, resid(ar(turnover, 3, method = "ols", rm.na=TRUE)), align="right", by.column=TRUE)
#testRoll<-ar(turnover, 3, method = "ols", rm.na=TRUE)

rm(turnover, volume, transactions, aTurnover,  aVolume, aTransactions, dataAdd, test)


#dealing with missing values
##replace NA with 0 for variables that allow this
data[c("PressAll", "PressPapers", "PressWires", "SVI", "AnnOwn", "AnnOwnSensitive", "RnD", "RnD2Sales",
       "EPS1NE", "EPS1NET", "EPS1SD", "EPS1MN", "EPS1UP", "EPS1DN",
       "DeprExpense", "MInterest","PrefShares", "ShortTDebt", "TaxPayable",
       "SGA", "SGA2Sales", "MInterestIS", "LegalCost",  
       "SVI_NEW", "SVI_AU", "SVI_ASX",  
       "PressWiresMajor", "PressWiresMinor", "PressPapersMajor", "PressPapersMinor",
       "RnD_BS", "RnD2Sales5Y")] [is.na(data[c("PressAll", "PressPapers", "PressWires", "SVI", "AnnOwn", "AnnOwnSensitive", "RnD", "RnD2Sales",
                                               "EPS1NE", "EPS1NET", "EPS1SD", "EPS1MN", "EPS1UP", "EPS1DN",
                                               "DeprExpense", "MInterest","PrefShares", "ShortTDebt", "TaxPayable",
                                               "SGA", "SGA2Sales", "MInterestIS", "LegalCost",  
                                               "SVI_NEW", "SVI_AU", "SVI_ASX",  
                                               "PressWiresMajor", "PressWiresMinor", "PressPapersMajor", "PressPapersMinor",
                                               "RnD_BS", "RnD2Sales5Y")])]=0

#lagging several variables so they sit on their one place
#before laggin data2 needs to be sorted by date.  The date should be ascending (i.e. increasing as it moves down the rows).
#Also, the time difference between rows should be constant, e.g. days, months, years.
data<-data[order(data$code, data$date),] #order dataR by code and then by date

##lag variables for +1 month: SVI, SVI_NEW, SVI_ASX, SVI_AU, 
data<-slide(data, Var = "SVI", TimeVar="date", GroupVar = "code", NewVar="SVI", slideBy = -1)
data<-slide(data, Var = "SVI_NEW", TimeVar="date", GroupVar = "code", NewVar="SVI_NEW", slideBy = -1)
data<-slide(data, Var = "SVI_ASX", TimeVar="date", GroupVar = "code", NewVar="SVI_ASX", slideBy = -1)
data<-slide(data, Var = "SVI_AU", TimeVar="date", GroupVar = "code", NewVar="SVI_AU", slideBy = -1)

#lag variables for +1 month: PressAll, PressPapers, PressPapersMajor, PressPapersMinor, PressWires, PressWiresMajor, PressWiresMinor
data<-slide(data, Var = "PressAll", TimeVar="date", GroupVar = "code", NewVar="PressAll", slideBy = -1)
data<-slide(data, Var = "PressPapers", TimeVar="date", GroupVar = "code", NewVar="PressPapers", slideBy = -1)
data<-slide(data, Var = "PressPapersMajor", TimeVar="date", GroupVar = "code", NewVar="PressPapersMajor", slideBy = -1)
data<-slide(data, Var = "PressPapersMinor", TimeVar="date", GroupVar = "code", NewVar="PressPapersMinor", slideBy = -1)
data<-slide(data, Var = "PressWires", TimeVar="date", GroupVar = "code", NewVar="PressWires", slideBy = -1)
data<-slide(data, Var = "PressWiresMajor", TimeVar="date", GroupVar = "code", NewVar="PressWiresMajor", slideBy = -1)
data<-slide(data, Var = "PressWiresMinor", TimeVar="date", GroupVar = "code", NewVar="PressWiresMinor", slideBy = -1)

#lag variables for +1 month: AnnOwn, AnnOwnSensitive
data<-slide(data, Var = "AnnOwn", TimeVar="date", GroupVar = "code", NewVar="AnnOwn", slideBy = -1)
data<-slide(data, Var = "AnnOwnSensitive", TimeVar="date", GroupVar = "code", NewVar="AnnOwnSensitive", slideBy = -1)

#calculate % of PressPapersMajor to PressPapers
data$PressPapersMajor_Pc<-ifelse(data$PressPapers>0, data$PressPapersMajor/data$PressPapers, 0)
  
#calculate % of PressWiresMajor to PressWires
data$PressWiresMajor_Pc<-ifelse(data$PressWires>0, data$PressWiresMajor/data$PressWires, 0)

#calculate % of AnnOwnSensitive to AnnOwn
data$AnnOwnSensitive_Pc<-ifelse(data$AnnOwn>0, data$AnnOwnSensitive/data$AnnOwn, 0)

#calculate dual variable for PressAll
data$PressAllD<-ifelse(data$PressAll>0, 1, 0)

#calculate dual variable for PressPapers
data$PressPapersD<-ifelse(data$PressPapers>0, 1, 0)

#calculate dual variable for PressPapersMajor
data$PressPapersMajorD<-ifelse(data$PressPapersMajor>0, 1, 0)

#calculate dual variable for PressWires
data$PressWiresD<-ifelse(data$PressWires>0, 1, 0)

#calculate dual variable for PressWairesMajor
data$PressWiresMajorD<-ifelse(data$PressWiresMajor>0, 1, 0)

#calculate dual variable for AnnOwn
data$AnnOwnD<-ifelse(data$AnnOwn>0, 1, 0)

#calculate dual variable for AnnOwnSensitive
data$AnnOwnSensitiveD<-ifelse(data$AnnOwnSensitive>0, 1, 0)

#calculate dual variable for RnD
data$RnDD<-ifelse(data$RnD>0, 1, 0)

#calculate dual variable for RnD2Sales
data$RnD2SalesD<-ifelse(data$RnD2Sales>0, 1, 0)

#calculate dual variable for SGA
data$SGAD<-ifelse(data$SGA>0, 1, 0)

#calculate dual variable for SGA2Sales
data$SGA2SalesD<-ifelse(data$SGA2Sales>0, 1, 0)

#calculate sales growth
data<-change(data, Var="Sales", GroupVar="code", TimeVar="date", NewVar="SalesGrowth", slideBy=-12, type= "proportion")

#reCalculate RnD2Sales - many missing values
data$RnD2Sales_new<-data$RnD/data$Sales

#reCalculate SGA2Sales - many missing values
data$SGA2Sales_new<-data$SGA/data$Sales

#Calculate ROA=
data$ROA<-data$NetIncome/data$TA*100

#reCalculate MBTV due to high missing numbers
data$MarketCapDivTEquity<-data$MarketCap/data$TEquity #for some reason MTBV shows higher correlation with this variable rather than with separate variables

#calculate legal costs/sales - my own, not from the literature
data$Legal2Sales<-data$LegalCost/data$Sales

##calculate Re2TA
data$RE2TA<-data$RE/data$TA

#calculation of MTBV using FF method (B2MV_FF): they match fiscal year end book equity with market value at the same time
## for AU it is likely to be July, so book value needs to be matched with market cap for July
#data$MTBV_FF
julyS<-seq(as.Date("1999-07-01"), as.Date("2016-07-01"), by="year")
MTBV_FF<-data[data$date %in% julyS, c("code", "date","MarketCap", "TEquity")]
MTBV_FF$B2MV_FF<-MTBV_FF$TEquity/MTBV_FF$MarketCap
MTBV_FF$MarketCap<-NULL
MTBV_FF$TEquity<-NULL
MTBV_FF<-as.data.table(MTBV_FF)
setkey(MTBV_FF, code, date)

MTBV_FF_ext<-as.data.table(data[, c("code", "date")])
setkey(MTBV_FF_ext, code, date)
test<-MTBV_FF[MTBV_FF_ext, roll=TRUE]
test<-as.data.frame(test)
data<-merge(data, test, by=c("date","code"))
rm(test, MTBV_FF_ext, MTBV_FF, julyS)

# TO BE DONE !
#calculate AbnReturn - abn return can be calculated as monthly gross return - expected return (based on portfolio (French website data) OR index)
#calculate AbnVolume

#calculate Ability
# the dataset to be copied from is dataR (adjusted for winsorising and missing data)
dataAbility<-data[, c("date", "code", "RnD2Sales", "Sales", "SalesGrowth")]
dataAbility<-dataAbility[order(dataAbility$code, dataAbility$date),]
#dataAbility$RnD2SalesY_1: lag RnD 1 period
dataAbility<-slide(dataAbility, Var = "RnD2Sales", TimeVar="date", GroupVar = "code", NewVar="RnD2SalesY_1", slideBy = -12)
#dataAbility$RnD2SalesY_2
dataAbility<-slide(dataAbility, Var = "RnD2Sales", TimeVar="date", GroupVar = "code", NewVar="RnD2SalesY_2", slideBy = -24)
#dataAbility$RnD2SalesY_3
dataAbility<-slide(dataAbility, Var = "RnD2Sales", TimeVar="date", GroupVar = "code", NewVar="RnD2SalesY_3", slideBy = -36)
#dataAbility$RnD2SalesY_4
dataAbility<-slide(dataAbility, Var = "RnD2Sales", TimeVar="date", GroupVar = "code", NewVar="RnD2SalesY_4", slideBy = -48)
#dataAbility$RnD2SalesY_5
dataAbility<-slide(dataAbility, Var = "RnD2Sales", TimeVar="date", GroupVar = "code", NewVar="RnD2SalesY_5", slideBy = -60)
#convert to data.table to manage data easier
dataAbility<-data.table(dataAbility)
#columns to be manipulated in the the dataset
var<-colnames(dataAbility[,c("RnD2SalesY_1","RnD2SalesY_2", "RnD2SalesY_3", "RnD2SalesY_4", "RnD2SalesY_5"), with=F])

setkey(dataAbility, code, date)

#calculate dataR$RnD2Sales5Y - to fill up missing values
dataAbility[, RnD2Sales5Y_N:=mean(as.numeric(.SD), na.rm=TRUE), .SDcol=var, by=.(code, date)]
dataAbility[is.na(RnD2Sales5Y_N), RnD2Sales5Y_N:=0, by=.(code, date)]

#calculculating number of not applicable cases per observation
dataAbility[, t:=sum(is.na(.SD)|.SD==0), .SDcol=var, by=.(code, date)] 

#calculating b1 for each year/each firm: it does not require lm as numbers are constat within a year
dataAbility[, b_1:=log(abs(SalesGrowth))/log(RnD2SalesY_1+1), by=.(code, date)]
dataAbility[, b_2:=log(abs(SalesGrowth))/log(RnD2SalesY_2+1), by=.(code, date)]
dataAbility[, b_3:=log(abs(SalesGrowth))/log(RnD2SalesY_3+1), by=.(code, date)]
dataAbility[, b_4:=log(abs(SalesGrowth))/log(RnD2SalesY_4+1), by=.(code, date)]
dataAbility[, b_5:=log(abs(SalesGrowth))/log(RnD2SalesY_5+1), by=.(code, date)]

#averaging coefficients
dataAbility[as.numeric(t)<4, Ability:=mean(as.numeric(.SD), na.rm=TRUE), .SDcols=c("b_1", "b_2", "b_3", "b_4", "b_5"), by=.(code, date)]

#replace all NA and inf with 0: zeros should be ignored
dataAbility[(is.na(Ability)|is.infinite(Ability)), Ability:=0, by=.(code, date)]

#dataAbilityTest<-dataAbility[Ability>0,] #to see available solutions, others are NA.
#merge with existing dataset (dataR)
#remove columns not to be used further and prepare for mering with the main set
dataAbility[, c("RnD2Sales", "Sales","SalesGrowth","RnD2SalesY_1","RnD2SalesY_2", "RnD2SalesY_3", "RnD2SalesY_4", "RnD2SalesY_5", "b_1", "b_2", "b_3", "b_4", "b_5", "t"):=NULL]
dataAbility<-as.data.frame(dataAbility)
#merge with data keeping only Ability there
data<-merge(data, dataAbility, by=c("date","code"))
rm(dataAbility)

#calculating the same thing for SGA2Sales and AbilitySGA
# the dataset to be copied from is dataR (adjusted for winsorising and missing data)
dataSGA<-data[, c("date", "code", "SGA2Sales", "Sales", "SalesGrowth")]
dataSGA<-dataSGA[order(dataSGA$code, dataSGA$date),]
#dataSGA$SGA2SalesY_1: lag RnD 1 period
dataSGA<-slide(dataSGA, Var = "SGA2Sales", TimeVar="date", GroupVar = "code", NewVar="SGA2SalesY_1", slideBy = -12)
dataSGA<-slide(dataSGA, Var = "SGA2Sales", TimeVar="date", GroupVar = "code", NewVar="SGA2SalesY_2", slideBy = -24)
dataSGA<-slide(dataSGA, Var = "SGA2Sales", TimeVar="date", GroupVar = "code", NewVar="SGA2SalesY_3", slideBy = -36)
dataSGA<-slide(dataSGA, Var = "SGA2Sales", TimeVar="date", GroupVar = "code", NewVar="SGA2SalesY_4", slideBy = -48)
dataSGA<-slide(dataSGA, Var = "SGA2Sales", TimeVar="date", GroupVar = "code", NewVar="SGA2SalesY_5", slideBy = -60)
#convert to data.table to manage data easier
dataSGA<-data.table(dataSGA)
#columns to be manipulated in the the dataset
var<-colnames(dataSGA[,c("SGA2SalesY_1","SGA2SalesY_2", "SGA2SalesY_3", "SGA2SalesY_4", "SGA2SalesY_5"), with=F])

setkey(dataSGA, code, date)

#calculate dataR$SGA2Sales5Y - to fill up missing values
dataSGA[, SGA2Sales5Y_N:=mean(as.numeric(.SD), na.rm=TRUE), .SDcol=var, by=.(code, date)]
dataSGA[is.na(SGA2Sales5Y_N), SGA2Sales5Y_N:=0, by=.(code, date)]

#calculculating number of not applicable cases per observation
dataSGA[, t:=sum(is.na(.SD)|.SD==0), .SDcol=var, by=.(code, date)] 

#calculating b1 for each year/each firm: it does not require lm as numbers are constat within a year
dataSGA[, b_1:=log(abs(SalesGrowth))/log(SGA2SalesY_1+1), by=.(code, date)]
dataSGA[, b_2:=log(abs(SalesGrowth))/log(SGA2SalesY_2+1), by=.(code, date)]
dataSGA[, b_3:=log(abs(SalesGrowth))/log(SGA2SalesY_3+1), by=.(code, date)]
dataSGA[, b_4:=log(abs(SalesGrowth))/log(SGA2SalesY_4+1), by=.(code, date)]
dataSGA[, b_5:=log(abs(SalesGrowth))/log(SGA2SalesY_5+1), by=.(code, date)]

#averaging coefficients
dataSGA[as.numeric(t)<4, AbilitySGA:=mean(as.numeric(.SD), na.rm=TRUE), .SDcols=c("b_1", "b_2", "b_3", "b_4", "b_5"), by=.(code, date)]

#replace all NA and inf with 0: zeros should be ignored
dataSGA[(is.na(AbilitySGA)|is.infinite(AbilitySGA)), AbilitySGA:=0, by=.(code, date)]

#dataSGATest<-dataSGA[AbilitySGA>0,] #to see available solutions, others are NA.
#merge with existing dataset (dataR)
#remove columns not to be used further and prepare for mering with the main set
dataSGA[, c("SGA2Sales", "Sales","SalesGrowth","SGA2SalesY_1","SGA2SalesY_2", "SGA2SalesY_3", "SGA2SalesY_4", "SGA2SalesY_5", "b_1", "b_2", "b_3", "b_4", "b_5", "t"):=NULL]
dataSGA<-as.data.frame(dataSGA)
#merge with data keeping only Ability there
data<-merge(data, dataSGA, by=c("date","code"))
rm(dataSGA, var)

#1. remove based on registration date till June 30 2016 (recorded as 2016-06-01) -

#assign listing dates/delisting
listingDates<-read.csv("Listing dates.csv")
listingDates$Listed=as.Date(listingDates$Listed, format="%d/%m/%Y")
listingDates$Delisted=as.Date(listingDates$Delisted, format="%d/%m/%Y")
data<-merge(data, listingDates, by.x="code", by.y="Code")
data$isListed=0
data[(!is.na(data$Delisted) & data$date<data$Delisted & data$date>data$Listed),"isListed"]=1 #if listed within the period of listing date to delisting date
data[(is.na(data$Delisted) & data$date>data$Listed),"isListed"]=1 # if there is no delisted date, but data is after the listing date
rm(listingDates)

##calculate age of the company from registration to obs time (in months)
data$Age<-as.numeric(difftime (data$date, data$Listed, units="weeks"))

## start from here for a new dataset
data2<-data[data$date>="2004-01-01" & !data$isListed==0,] #copy to data2 only those entries that are within listing and after 2004 since Google SVI started in 2004
#data2<-data[!data$isListed==0,] #copy to data2 only those entries that are within listing and after 2004 since Google SVI started in 2004

data2$Listed<-NULL
data2$Delisted<-NULL
#data2$isListed<-NULL can this be used to calculate Ability?

#remove upper (latest dates for which statements are not yet available). This was done manually earlier, so it is NOT needed in this round
#datesExclude<-seq(as.Date("2016-01-01"), as.Date("2016-07-01"), "month")
#dataR<-data2[!data2$date %in% datesExclude,]
#rm(datesExclude)
##assign ASX100 and ASX200 listing
asx100<-read.csv("asx100.csv")
asx100$date<-as.Date(asx100$date, format="%d/%m/%Y")
asx200<-read.csv("asx200.csv")
asx200$date<-as.Date(asx200$date, format="%d/%m/%Y")
test<-data2[, c("code", "date")]
test<-merge(test, asx100, by.x="date", by.y="date", all.x=TRUE)
test$ASX100<-as.numeric(apply(test, 1, function(x) x[2] %in% x[3:112])) # locate if in the index for that month for that company
test2<-test[,c("date", "code","ASX100")]
data2<-merge(data2, test2, by=c("date","code"))
#ASX200 assignment
rm(test, test2)
test<-data2[, c("code", "date")]
test<-merge(test, asx200, by.x="date", by.y="date", all.x=TRUE)
test$ASX200<-as.numeric(apply(test, 1, function(x) x[2] %in% x[3:215])) # locate if in the index for that month for that company
test2<-test[,c("date", "code","ASX200")]
data2<-merge(data2, test2, by=c("date","code"))
rm(test, test2, asx100, asx200)

#assign current industries
industry<-read.csv("current industry.csv")
data2<-merge(data2, industry, by="code")
rm(industry)
#remove outliers!!!! (1)

#winsorising of all variables except "code" and "date"
dataW<-data2 #copy it over for further manipulations
#below variables will be kept unchanged (nonWinsorised)
var2Keep<-c("date", "code", "Age","PressPapersD", "PressPapersMajorD", "PressWiresD", 
            "PressWiresMajorD", "AnnOwnD", "AnnOwnSensitiveD", "RnDD", "RnD2SalesD", "SGAD", "SGA2SalesD", "ASX100","ASX200", "industryName","sectorName")
dataW<-data.frame(dataW[names(dataW) %in% var2Keep], apply(dataW[!names(dataW) %in% var2Keep], 2, winsor1))
rm(var2Keep)



#local outlier factor algorithm for outliers identification
#test<-dataR[, 'PressAll']
#outlier.score<-lofactor(test, k=5)
#plot(density(outlier.score))

####IF Logging needs to be done prior to missing values cleaning - it needs to be done here

#3. Missing values - - Marketcap, Sales, EPS, Netincome are excluded, MTBV is calculated through MarketCap and TEquity
#calculate statistics for missing values 
# are values missing for the same cases?
#calculate % of missing values per company per variable
dataMissing=as.data.frame(as.list(aggregate(dataW[, c("Age","MarketCap","Sales","ROA","RnD2Sales_new", "SalesGrowth", "SGA2Sales5Y",
  "RnD2Sales5Y", "PressPapersMajor", "PressWiresMajor","MarketCapDivTEquity", "MTBV", "B2MV_FF", "Legal2Sales", "RE2TA","DWRE",
  "NetIncome", "EntValue", "SVI_ASX", "SVI_AU", "SVI_NEW", "LegalCost", "TA", "EPS", "SGA2Sales",  "EPS1DN",
  "EPS1UP", "EPS1MN", "EPS1SD", "EPS1NET", "EPS1NE", "RnD2Sales", "AnnOwnSensitive", "AnnOwn", "SVI",
  "PressWires", "PressPapers", "PressPapersMajor_Pc", "PressWiresMajor_Pc", "AnnOwnSensitive_Pc", "TEquity")], list(code=dataW$code), function (x) c(PR=sum(is.na(x))/length(x)*100, OBS=length(x)))))

write.csv(dataMissing, file="missing values.csv") # write into file for checking

#remove firms with missing MarketCaps in some observations - other variables are missing for those firms as well
codes2Exclude<-as.vector(dataMissing[dataMissing$MarketCap.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataW[!dataW$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
length(unique(dataR$code)) #see how many firms are left

#missing values in Sales - DO ROLLING REGRESSION TOMORROW!
codes2Exclude<-as.vector(dataMissing[dataMissing$Sales.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
#this part is very specific to the dataset!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

test<-dataR[dataR$code %in% codes2Exclude, c("date", "code", "Sales")]

dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
sum(is.na(dataR$Sales))


##!!!!!!!!clean SalesGrowth - STOPPED HERE
#missing values in SalesGrowth 
codes2Exclude<-as.vector(dataMissing[dataMissing$SalesGrowth.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
sum(is.na(dataR$SalesGrowth))

#All SalesGRowth ==0 are removed. this can be imputated.
codes2Exclude<-as.vector(dataR[dataR$SalesGrowth==0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well

##!!!!!!!!clean SalesGrowth - STOPPED HERE

#missing values in EPS - CAN THIS BE JUST RECALCULATED? IS EPS IS INDEED CRUCIAL????
codes2Exclude<-as.vector(dataMissing[dataMissing$EPS.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
sum(is.na(dataR$EPS))

#missing values in NetIncome - would this be more logical to fix net income first (if it is indeed very very necessary)
codes2Exclude<-as.vector(dataMissing[dataMissing$NetIncome.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
sum(is.na(dataR$NetIncome))

#replace missing values in MTBV using regression
#remove observations where MarketCap (already removed) and/or TEquity are not available
#codes2Exclude<-as.vector(dataMissing[dataMissing$MTBV.PR>0 & dataMissing$TEquity.PR>0,"code"])
#dataR<-dataR[!dataR$code %in% codes2Exclude,] #use dataR since some companies with NA in MarketCap were already excluded
#dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well

MTBVMissing<-as.vector(dataMissing[dataMissing$MTBV.PR>0, c("code")])
#length(MTBVMissing) #number of companies to work with missing MTBV in original dataset

#STOPPED HERE - to be extended!!!!!
test_missingData<-dataR[dataR$code %in% MTBVMissing, c("date","code", "MarketCap", "TEquity", "MTBV", "MarketCapDivTEquity")]

length(unique(test_missingData$code)) # number of companies in the latest dataset to work with (some companies were excluded due to missing MarketCap)
#next line is optional to see
#test_missingData[,-1] %>% correlate (method="spearman") %>% focus (MTBV) #%>% is the pipe operator

#using regression to calculate missing values via MarketCapDivTEquity
data4Regr <- dataR[!is.na(dataR$MTBV), c("date","code","MTBV", "MarketCapDivTEquity", "MarketCap", "TEquity")] #offset data for calculating regression coefficients - full observations only for MTBV
MTBV_model<-lm(MTBV~MarketCapDivTEquity, data=data4Regr) #run the regression model                                         
##replace missing values in the test_missingData for further work
test_missingData$MTBV[is.na(test_missingData$MTBV)]<-predict(MTBV_model, newdata=test_missingData[is.na(test_missingData$MTBV),]) #use coefficients to calculate missing values
#still have 84 cases missing due to missing MarketCapDivTEquity
sum(is.na(test_missingData$MTBV))
sum(is.na(dataR$MTBV))
dataR$MTBV[is.na(dataR$MTBV)]<-predict(MTBV_model, newdata=dataR[is.na(dataR$MTBV),]) #use coefficients to calculate missing values
sum(is.na(dataR$MTBV)) #check number of missing values in MTBV after the regression replacement

#using regression to calculate missing values via MarketCap and TEquity
##use rolling join to fill up values for TEquity.
#MarketCap has no missing values
test_missingData<-data.table(test_missingData)
setkey(test_missingData, code, date)
#TEquity_N is reconstructed value for TEquity through rolling join
test_missingData[, TEquity_N:=test_missingData[!is.na(TEquity)][test_missingData, TEquity, roll=T]]
test_missingData[, TEquity_N:=test_missingData[!is.na(TEquity_N)][test_missingData, TEquity_N, roll=-Inf]]
sum(is.na(test_missingData$TEquity_N)) #check if all NAs are filled
sum(is.na(test_missingData$TEquity))#checking number of replacements to be done
test_missingData[is.na(TEquity), TEquity:=TEquity_N, by=.(date, code)] #replacing TEquity with TEquity_N if missing values
sum(is.na(test_missingData$TEquity)) #checking if replacement is ok

#regression itself to calculate missing values in MTBV using MarketCap and TEquity
MTBV_model<-lm(MTBV~MarketCap+TEquity, data=data4Regr)
test_missingData$MTBV[is.na(test_missingData$MTBV)]<-predict(MTBV_model, newdata=test_missingData[is.na(test_missingData$MTBV),]) #use 
sum(is.na(test_missingData$MTBV))
test_missingData$MTBV_N<-test_missingData$MTBV 
test<-test_missingData[, .(code, date, MTBV_N)]
dataR<-merge(dataR, test, all=TRUE, by=c("code","date")) #merge dataframes to replace in the main dataset dataR - this is the most efficient way of doing it
dataR$MTBV<-ifelse(is.na(dataR$MTBV), dataR$MTBV_N, dataR$MTBV) #replacement itself
dataR$MTBV_N<-NULL
sum(is.na(dataR$MTBV)) #check if all is correct
rm(data4Regr, MTBV_model, MTBVMissing, test_missingData, test) #remove unnecessary

#calculate RE/Total assets: clean TA and RE  - from Altman Z score model: proxy for company age and earning power
##remove companies with missing RE
codes2Exclude<-as.vector(dataMissing[dataMissing$RE2TA.PR>0,"code"])
length(codes2Exclude) #see how many firms to exclude
dataR<-dataR[!dataR$code %in% codes2Exclude,] #exclude from dataR
dataMissing<-dataMissing[!dataMissing$code %in% codes2Exclude,] #exclude from dataMissing as well
sum(is.na(dataR$RE2TA))

#clean ROE - it is easier to calculate this for missing data
dataR$DWRE<-ifelse(is.na(dataR$DWRE), dataR$NetIncome/dataR$TEquity, dataR$DWRE) #if DWRE is not available (usually due to loss)
sum(is.na(dataR$DWRE))

#clean Legal2Sales - all NA are converted to 0
dataR$Legal2Sales<-ifelse(is.na(dataR$Legal2Sales), 0, dataR$Legal2Sales) 
sum(is.na(dataR$Legal2Sales))



# STOPPED HERE.  
##ADDITIONAL VARIABLES TO BE CONSIDERED -needs to be cleaned

#Clean ROA
sum(is.na(dataR$ROA))

#clean EntValue
sum(is.na(dataR$EntValue))

#clean Debt2Assets
sum(is.na(dataR$Debt2Assets))

#clean NOSH (can this be re-estimated through MarketCap and Share Price?)
sum(is.na(dataR$NOSH))

# STOPPED HERE. 

#remove all additional variables
rm (codes2Exclude, dataMissing)

dataL<-data.table(dataR) #dataset for log transformation

#Log transform needs to be done before missing data cleaning - regression and other imputation assumes normality
#log transformation for Press, SVI, Ann, AnnOwn, EPS1NE, EPS1NET related variables

#TO BE DONE LATER: plot(density(dataL$PressAll)) - to test if the data is normal. Use Cox Box test to see what 
##transformation is required - needs to be investigated

dataL$PressAll<-log(dataL$PressAll+1)
dataL$PressPapers<-log(dataL$PressPapers+1)
dataL$PressPapersMajor<-log(dataL$PressPapersMajor+1)
dataL$PressPapersMinor<-log(dataL$PressPapersMinor+1)
dataL$PressWires<-log(dataL$PressWires+1)
dataL$PressWiresMajor<-log(dataL$PressWiresMajor+1)
dataL$PressWiresMinor<-log(dataL$PressWiresMinor+1)
dataL$SVI<-log(dataL$SVI+1)
dataL$SVI_NEW<-log(dataL$SVI_NEW+1)
dataL$SVI_AU<-log(dataL$SVI_AU+1)
dataL$SVI_ASX<-log(dataL$SVI_ASX+1)
dataL$AnnOwn<-log(dataL$AnnOwn+1)
dataL$AnnOwnSensitive<-log(dataL$AnnOwnSensitive+1)
dataL$EPS1NE<-log(dataL$EPS1NE+1)
dataL$EPS1NET<-log(dataL$EPS1NET+1)

#log transform for independent variables: MarketCap, SalesGrowth, EPS, SGA,
#questionable if needed for , RnD2Sales, SGA2Sales, DWRE
dataL$Age<-log(dataL$Age)
dataL$MarketCap<-log(dataL$MarketCap)
dataL$Sales<-log(dataL$Sales)
dataL$SalesGrowth<-log(dataL$SalesGrowth+1)  # Logged SalesGrowth - DO NOT THINK THAT THIS IS THE CORRECT WAY, needs to be without +1

#dataL$ROA<-log(dataL$ROA) negative - cannot be logged

dataL$MarketCapDivTEquity<-log(dataL$MarketCapDivTEquity)
dataL$MTBV<-log(dataL$MTBV)
dataL$Legal2Sales<-log(dataL$Legal2Sales+1)
#dataL$RE2TA<-log(dataL$RE2TA+1) #cannot be logged
#dataL$DWRE<-log(dataL$DWRE+1) #cannot be logged
#dataL$NetIncome<-log(dataL$NetIncome+1) # cannot be logged
dataL$TA<-log(dataL$TA)
#EntValue - contains NA 
dataL$EPS<-log(dataL$EPS+1)

#this part went missing ....
#calculates year out of date - just in case
dataL[, year:=year(date)] #add a new column = year (calculate out of date)



