## do K-Means cluster analysis on combinations of visibility variables
#check ClusterMeans from 2015-01-01 - no zeros???
summary(dataL[,c("PressAllCluster", "PressPapersCluster")])
library(ggplot2) 
library(NbClust)
library(fpc)
library(psych)
library(data.table)  

elbowMethod<-function (x) {#function to calculate elbow method
  
  wss <- (nrow(x)-1)*sum(apply(x,2,var))
  for(i in 1:25){wss[i] <- sum(kmeans(x, centers=i)$withinss)}
  plot(1:25, wss, type="b", xlab="No. of Clusters", ylab="wss")  #plotting the curve
  return (wss)
}


#testCluster - is a copy of dataL for clustering (to save memory)
#res - the results of NbClust (algorithm to determine the optimal number of clusters)


#Principal component analysis: needs to be log transformed and scaled first

#1. cross-section clustering

#1.0 Kmeans - how to select variables for clustering

#1.1. Clustering pooled  


#- Elbow method
#fpc - cluster assessment
#- NbClust - model based clustering

#1.1.1.Remove  observations with all 0s into a separate cluster
#- NbClust
#- Elbow method
#start with a minimum number of variables and then extend: 
#statistics to report: sse; cluster centres
#visualisation of clusters



#1.2. Clustering per month
#______________________________________
#1.1.1.Remove  observations with all 0s  into a separate cluster
#- NbClust
#- Elbow method


#2. model based evaluation of clustering  



#2. time series clustering

#trying using NbCLust- package to determine the best number of clusters

#1. pooled clustering
#clustering variables assignmnent
#cols<-colnames(dataL[,c("PressAll", 
                        
  #                             "SVI_NEW"), with=F])


#The below set is just for PCA - it can be omitted if not PCA is done
cols<-colnames(dataL[,c("PressWires",
                        "PressPapers",
                        "PressPapersMajor",
                        "PressWiresMajor", 
                        
                        
                        "SVI_ASX",
                        "SVI_AU",
                        "SVI_NEW"
                        
                        ), with=F])

testCluster<-(dataL[, .SD, .SDcols=cols]) #copy observations so it is more manageable re size

#PCA
results <- prcomp(testCluster,
                 center = TRUE,
                 scale. = TRUE) 
print(results)
plot(results, type = "l")
summary(results)

#__________________ varimax rotation


fit <- principal(testCluster, nfactors=2, rotate="oblimin")
print(fit)

#_______________________ exploratory factor analysis

# Maximum Likelihood Factor Analysis
# entering raw data and extracting 3 factors, 
# with varimax rotation 
fit <- factanal(testCluster, 2, rotation="varimax")
print(fit, digits=2, cutoff=.3, sort=TRUE)
# plot factor 1 by factor 2 
load <- fit$loadings[,1:2] 
plot(load,type="n") # set up plot 
text(load,labels=names(testCluster),cex=.7) # add variable names

#____________________________CLUSTERING

#move on to clustering
##only those variables are kept which showed greater importance in PCA and above
##factor1 (>0.80), factor 2 (>0.8)
#THE SET BELOW IS FOR CLUSTERING!
cols<-colnames(dataL[,c("PressWires",
                        "PressPapers",
                        "PressPapersMajor",
                        "PressWiresMajor", 
                        "SVI_AU",
                        "SVI_NEW"), with=F])

testCluster<-(dataL[, .SD, .SDcols=cols]) #copy observations so it is more manageable re size
testCluster<-scale(testCluster) #SCALING old way with no codes or dates
#clusterCenter <- attr(testCluster, "scaled:center")  
#clusterScale <- attr(testCluster, "scaled:scale")

#scaling with dates and codes
#testCluster[, -c("date","code")]<-scale(testCluster[, -c("date","code"), with=FALSE]) #SCALING!!!!

#using the Elbow method
elbowMethod (testCluster)

# number 4 was proposed to be the best number of clusters
fit.km <- kmeans(testCluster, 4, nstart=25)   
fit.km$centers
fit.km$size

#____________ CLUSTER ASSIGNMENT____________
# append cluster assignment
export<-fit.km$cluster
dataL[,"ClusterKMeans"]<-export
clusterDistribution<-dataL[,.N, by=c("date", "ClusterKMeans")]
write.csv(clusterDistribution, file="clusterDistribution.csv")
trans.matrix_full(dataL, "ClusterKMeans", TRUE) #transition matrix for clusters 

#____________ CLUSTER ASSIGNMENT END____________



#ALTERNATIVE VERSION

#____________ CLUSTER ASSIGNMENT begin ____________
cols<-colnames(dataL[,c(
  "PressWires",
                        "PressPapers",
                        "PressPapersMajor",
                        "PressWiresMajor", 
                        
                        "SVI_AU",
                        "SVI_NEW"
                        
), with=F])

testCluster<-(dataL[, .SD, .SDcols=cols])
#testCluster<-cbind (testCluster[, c(code, date)],scale(testCluster[, c(-1, -2)]))

# K-Means Cluster Analysis - with 
fit <- kmeans(testCluster[, c(-1, -2)], 4, nstart=20) # 4 cluster solution
fit$centers

# append cluster assignment
dataL$Cluster <- fit$cluster


#alternative assignment using data.table
test<-dataL[, kmeans(as.matrix(scale(cbind(.SD))), 4, nstart=20), .SDcols=cols]
test$centers
dataC<-data.frame(dataL, test$centers)



#____________ CLUSTER ASSIGNMENT END____________


## Visualize the clusters - needs to be DONE TODAY!!!!
#fit.km$cluster <- as.factor(fit.km$cluster)
#testCluster<-as.data.frame(testCluster)
#ggplot(testCluster, aes(PressAll, SVI_NEW, color = fit.km$cluster)) + geom_point()

#-_____ pamk from fpc Package

#PAM is similar to K-Means, but it is more robust with outliers. It can be implemented using pam() from cluster package.
library(cluster)
results<-pam(testCluster, 4)
summary(results)
export<-results$cluster
dataL[,"ClusterPAM"]<-export

##calls the function pam or clara to perform a partitioning around medoids clustering with 
##the number of clusters estimated by optimum average silhouette width (see pam.object) or Calinski-Harabasz index (calinhara).
results<-pamk(testCluster, krange=1:10, criterion="multiasw", usepam=FALSE, critout=TRUE)
summary(results)
str(results)
results$nc

#___________________ hierarchical clustering
# Ward Hierarchical Clustering
d <- dist(testCluster, method = "euclidean") # distance matrix
fit.hc <- hclust(d, method="ward.D2") 
plot(fit.hc) # display dendogram
groups <- cutree(fit.hc, k=4) # cut tree into 4 clusters
# draw dendogram with red borders around the 4 clusters 
rect.hclust(fit.hc, k=4, border="red")

#---------------FPC-------------
#using clusterboot()

# set the desired number of clusters                               
kbest.p<-5       

#   Run clusterboot() with hclust 
#   ('clustermethod=hclustCBI') using Ward's method 
#   ('method="ward"') and kbest.p clusters 
#   ('k=kbest.p'). Return the results in an object 
#   called cboot.hclust.
testCluster<-data.table(testCluster)
 

#   The results of the clustering are in 
#   cboot.hclust$result. The output of the hclust() 
#   function is in cboot.hclust$result$result. 
#
#   cboot.hclust$result$partition returns a 
#   vector of clusterlabels. 

results<- clusterboot(testCluster,B=3,bootmethod=
                        c("boot","noise","jitter"),clustermethod=kmeansCBI,
                      krange=4,seed=15555)
print(results)
plot (results)


#model based clustering NbClust
res <- NbClust(testCluster, min.nc=2, max.nc=12, method="kmeans") # determining the number of clusters and proposes to user the best clustering scheme
res$All.index

barplot(table(res$Best.n[1,]), #shows the best number of clusters to use
        xlab="Number of Clusters", ylab="Number of Criteria",
        main="Number of Clusters Chosen by 26 Criteria")

table(res$Best.n[1,])


colsCluster<-colnames(dataL[,c(
                        "PressPapersMajor",  
                        "SVI_NEW"), with=F])

#experimenting with clustering
##clustering in one month - the results should not be different if scaling is done on the full dataset. 
##what if the scaling is done in one month only????
testC<-dataL[date==("2014-11-01"), .SD, .SDcols=colsCluster]
testC<-scale(testC) # SCALING

#stopped here!!!!!!!!!!!!!!!!!!!!!__________________________________
#needs to check this part!!!!!!!!!!!!!!

x0 <- dataL[,data.table(kmeans(cbind(.SD),centers=2)$centers), .SDcols=colsCluster,by=date] #clustering in each month
x <- dataL[(PressPapersMajor>0),data.table(kmeans(cbind(.SD),centers=2)$centers), .SDcols=colsCluster,by=date] #clustering in each month

#solution with all press/svi variables
test2Scale<-subset(dataR, select =c("wPressPapers", "wPressPapersMajor", "wPressWires", "wPressWiresMajor", "SVI_NEW", "SVI_AU", "SVI_ASX")) 
test2Scale<-data.table(scale(test2Scale))
dataR$VisibilityCluster4<-visibilityCluster$cluster
visibilityCluster$centers


#THIS CODE NEEDS TO BE CHECKED AND POSSIBLY DELETED - OLD CODE

library(ggplot2)
ggplot(testC, aes(PressPapersMajor, SVI_NEW))+geom_point()
##ggplot(testC, aes(AnnOwn, SVI, color=ASX100))+geom_point()

visibilityCluster<-kmeans(dataR[, c("zPressPapersCluster", "SVI_NEWCluster")], 3, nstart=20)
visibilityCluster<-kmeans(dataR[, c("lPressPapers", "lSVI_ASX")], 4, nstart=20)#best so far
visibilityCluster<-kmeans(dataR[, c("lPressWires", "lSVI_ASX")], 3, nstart=20)
visibilityCluster<-kmeans(dataR[, c("nPressPapers", "nSVI_ASX")], 3, nstart=20)
visibilityCluster<-kmeans(dataR[, c("lPressPapers", "lSVI_ASX", "lAnnOwn", "lEPS1NE")], 4, nstart=20)#best so far

visibilityCluster<-kmeans(dataR[, c("lPressPapers", "lSVI_NEW", "lEPS1NE")], 3, nstart=20)
visibilityCluster$centers
visibilityCluster$size
visibilityCluster$withinss
visibilityCluster$betweenss