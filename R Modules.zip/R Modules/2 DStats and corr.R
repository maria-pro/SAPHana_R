#TO BE DONE:calculate MTBV as it was done in FF: market cap and equity as at June previous year
#lag all balance sheet and income statements items!

#VData is the dataset used to show skewness in the original data: it is copied from data2 dataset 
#(with missing data, present outliers - no winsorising, no log)
#dataF is data never used!

#visibilityT is the dataset with median split groups (0=0, 1- below median, 2- above median)
#corAverage is the dataset with correlation coefficients that are calculated via time-series and then just averaged
#corFishers is the dataset with correlations as above but Fishers' transformation is applied first and then averages are calculated
#corPerFirm is the dataset with correlations calculated per firm basis



#autocorrelations

# Function to calculate first-order Markov transition matrix. - THIS IS A BASIC ONE TO BE USED FURTHER
# Each *row* corresponds to a single run of the Markov chain
#the transition counts (prob=FALSE) or, by default (prob=TRUE), the estimated transition probabilities.
trans.matrix <- function(X, prob=T)
{
  tt <- table( c(X[,-ncol(X)]), c(X[,-1]) )
  if(prob) tt <- tt / rowSums(tt)
  tt
}

#Calculate transition matrix for a given variable between states of a firm (as number of cases) 
#THIS IS THE CODE TO BE USED FOR TRANSITION MATRIX calculation
trans.matrix_full <- function(x, variable, prob=FALSE)
{
  col<-quote(variable)
  transitionMatrix<-x[, .(code, date)]
  #transitionMatrix<-x[, .(code, date)]
  transitionMatrix$v<-x[, eval(col), with=FALSE]
  #head(transitionMatrix)
  transitionMatrix<-as.xts.data.table(dcast(data = transitionMatrix,formula = date~code,fun.aggregate = sum,value.var = "v"))
  #head(transitionMatrix)
  transitionMatrix<-t(transitionMatrix)
  tt <- table( c(transitionMatrix[,-ncol(transitionMatrix)]), c(transitionMatrix[,-1]) )
  if(prob) tt <- tt / rowSums(tt)
  rm(transitionMatrix)
  
  tt
}

#install.packages("fBasics")
#install.packages("DMwR")
install.packages("corrr")  # package to do multiple correlations 
install.packages ("DataCombine") #package to do lags in variables
install.packages ("dplyr")
install.packages("nloptr")
install.packages("plm")
install.packages ("data.table")
install.packages("fBasics") 
install.packages("psych") 
install.packages("xts")


#library(DMwR) #local outlier factor algorithm for outliers identification
#library(fBasics) #Calculate basic stats for the sample and per each company
#library(lubridate) # to calculate years? but there should be an easier way for sure.
library(dplyr)
library(corrr)   # package to do multiple correlations
library(DataCombine)
library (nloptr)
library (plm)
library(data.table)  
#library (stats)
library(fBasics)
library(psych)
library(xts) # autocorrelations

#function to count non-zero elements per year
nonZero<-function (x) { #function to calculate non 0 observations
  result=sum(x!=0)
  return(result)}

nonZeroPc<-function (x) { #function to calculate percentage of non 0 observations
  non0=sum(x!=0)
  result=non0/sum(!is.na(x))
  return(result)}

#the final dataset to work with is dataF: includes only selected variables 
dataF<-data.table(dataL[, .(date, code, 
                            aTransactions,
                            aVolume,
                            aTurnover,
                            transactions,
                            volume,
                            turnover,
                            Age, year, MarketCap,
                            Sales,
                            SalesGrowth,
                            ROA,
                            PressAll,
                            PressWires,
                            PressPapers,
                            PressPapersMajor,
                            PressWiresMajor, 
                            AnnOwnSensitive, 
                            AnnOwn,
                            SVI,
                            SVI_ASX,
                            SVI_AU,
                            SVI_NEW,
                            PressPapersMajor_Pc,
                            PressWiresMajor_Pc,
                            AnnOwnSensitive_Pc,
                            MarketCapDivTEquity,
                            MTBV,
                            B2MV_FF,
                            Legal2Sales,
                            RE2TA,
                            DWRE,
                            NetIncome,
                            EntValue,
                            LegalCost,
                            TA,
                            EPS,
                            EPS1DN,
                            EPS1UP,
                            EPS1MN,
                            EPS1SD,
                            EPS1NET,
                            EPS1NE,
                            RnD,
                            RnDD,
                            RnD2Sales,
                            RnD2SalesD,
                            RnD2Sales_new, 
                            RnD2Sales5Y,
                            RnD2Sales5Y_N,
                            Ability,
                            SGA,
                            SGAD,
                            SGA2Sales,
                            SGA2SalesD,
                            SGA2Sales_new,
                            SGA2Sales5Y,
                            SGA2Sales5Y_N,
                            AbilitySGA,
                            PressAllD,
                            PressPapersD,
                            PressPapersMajorD,
                            PressWiresD,
                            PressWiresMajorD,
                            AnnOwnD,
                            AnnOwnSensitiveD,
                            industryName,
                            sectorName,
                            ASX100, ASX200)] )

#summary statistics on visibility variables: working with unadjasted dataset data2 to show asymmetry in visibility
VTest<-data.table(data2)
##add yearly data instead of monthly data
VTest[, year:=year(date)] #add a new column = year (calculate out of date)

#calculate basic descriptive stats for the sample - IS THIS NEEDED?
dataL[, !c("code", "date", "industryName", "sectorName"), with=FALSE] %>% basicStats() %>% write.csv(file="statsAllSample.csv")

#calculate the length of time series for each company
code.length<-VTest[, .(Observation=.N), by=code]
min(code.length$Observation) #min legth of time-series in months
max(code.length$Observation) #max length of time-series in months
mean(code.length$Observation)
median (code.length$Observation)
sd(code.length$Observation)

#calculate the number of firms in each month
code.length<-VTest[, .(Observation=.N), by=date]
min(code.length$Observation) #min legth of time-series in months
max(code.length$Observation) #max length of time-series in months
mean(code.length$Observation)
median (code.length$Observation)
sd(code.length$Observation)


#number of observations for ASX100 and nonASX100 companies
dataL[, .N, by=ASX100]
##calculate total counts per observations per year
obsPerYear<-dataL[, .N, by=year] #dataL is used since it is without missing data

#identify companies with 0 in SVI(s) and Press(es) during the whole period

cols<-colnames(VTest[,c("PressAll",
                        "PressWires",
                        "PressPapers",
                        "PressPapersMajor",  
                        "PressWiresMajor", 
                        "EPS1NE",
                        "AnnOwnSensitive", 
                        "AnnOwn",
                        "aTransactions",
                        "aVolume",
                        "aTurnover",
                        "transactions",
                        "volume",
                        "turnover",
                        "SVI",
                        "SVI_ASX",
                        "SVI_AU",
                        "SVI_NEW",
                        "PressPapersMajor_Pc",
                        "PressWiresMajor_Pc",
                        "AnnOwnSensitive_Pc",
                        "PressAllD",
                        "PressPapersD",
                        "PressPapersMajorD",
                        "PressWiresD",
                        "PressWiresMajorD",
                        "AnnOwnD",
                        "AnnOwnSensitiveD",
                        "RnDD",
                        "SGAD"), with=F])

#unconditional coverage stats per year
NonZeros<-VTest[, lapply(.SD, nonZeroPc), .SDcols=cols, by=year]



cols<-colnames(VTest[,c("PressAll",
                        "PressWires",
                        "PressWiresMajor",
                        "PressPapers",
                        "PressPapersMajor",
                        "EPS1NE",
                        "AnnOwnSensitive", 
                        "AnnOwn",
                        "SVI_NEW"), with=F])
NonZerosMonth<-VTest[, lapply(.SD, nonZeroPc), .SDcols=cols, by=date]
NonZeroMonthMeans<-NonZerosMonth[, lapply(.SD, mean), .SDcols=cols] #mean nonzero observations across all months


#conditional PressAll, SVI_NEW and EPS1NE
vPressAll<-VTest[PressAll>0, .(meanPressAll=mean(PressAll), medianPressAll=median(PressAll)), by=year] #conditional PressAll
vPressPapers<-VTest[PressPapers>0, .(meanPressPapers=mean(PressPapers), medianPressPapers=median(PressPapers)), by=year] #conditional PressAll
vPressWires<-VTest[PressWires>0, .(meanPressWires=mean(PressWires), medianPressWires=median(PressWires)), by=year] #conditional PressAll
vSVI_NEW<-VTest[SVI_NEW>0, .(meanSVI=mean(SVI_NEW), medianSVI=median(SVI_NEW)), by=year] #conditional SVI_NEW
vEPS1NE<-VTest[EPS1NE>0, .(meanEPS1NE=mean(EPS1NE), medianEPS1NE=median(EPS1NE)), by=year] #conditional SVI_NEW
list(vPressAll, vPressPapers, vPressWires, vSVI_NEW, vEPS1NE) %>% Reduce(function(x, y) merge(x, y, by="year",  all=TRUE),.) %>% data.table(test)

#identify no-visibility firms per industry
vIndustry<-VTest[, lapply(.SD, nonZeroPc), .SDcols=cols, by=sectorName]
write.csv(vIndustry, file="Industry distribution with Visibility Pr") #to be used for plotting in Excel





#----------Correlation analysis

cols<-colnames(dataL[,c("PressAll",
                        "PressWires",
                        "PressPapers",
                        "PressPapersMajor",  
                        "PressWiresMajor", 
                        "EPS1NE",
                        "AnnOwnSensitive", 
                        "AnnOwn",
                        "aTransactions",
                        "aVolume",
                        "aTurnover",
                        "transactions",
                        "volume",
                        "turnover",
                        "SVI",
                        "SVI_ASX",
                        "SVI_AU",
                        "SVI_NEW",
                        "PressPapersMajor_Pc",
                        "PressWiresMajor_Pc",
                        "AnnOwnSensitive_Pc",
                        "PressAllD",
                        "PressPapersD",
                        "PressPapersMajorD",
                        "PressWiresD",
                        "PressWiresMajorD",
                        "AnnOwnD",
                        "AnnOwnSensitiveD",
                        "RnDD",
                        "SGAD",
                        "RnD2Sales_new", 
                        "RnD2Sales5Y_N",
                        "Ability",
                        "SGA2Sales_new",
                        "SGA2Sales5Y_N",
                        "AbilitySGA",
                        "Age",
                        "MarketCap",
                        "MarketCapDivTEquity",
                        "MTBV",
                        "B2MV_FF",
                        "EPS"), with=F])

#correlation across all companies all time periods - THIS IS VERY ROUGH DATA 
#Since different companies have different lenght in time series, correlations need to be done in time series first
#then needs to be averaged ideally through Fishers transformation

#dataL[, .SD, .SDcols=cols] %>%correlate(method = "spearman")%>%  shave() %>% fashion() %>% write.csv(file="Correlations per variable.csv")

#correlation per company across all time periods - the below is just to generate the file
#cor coefs are not valid
#corPerFirm<-dataL[, fashion(shave(correlate(.SD, method = "spearman")), decimals = 3, na_print = "NA"), .SDcols=cols, by=code] #this is done to have correlation matrix in a fancy form: just for the file
#write.csv(corPerFirm, file="CorPerFirm.csv") #this is the file for further work in Excel and copy/paste in the paper

corPerFirm<-dataL[, correlate(.SD, method = "spearman"), .SDcols=cols, by=code] #this is raw for further work
write.csv(corPerFirm, file="corPerFirm.csv")

#averaging the "normal way"
corAverage<-corPerFirm[, lapply(.SD, function (x) mean(na.omit(x))), .SDcols=cols, by=rowname] #this should be similar to corFishers
write.csv(corAverage, file="corAverage.csv")

#this is an alternative to the above 
#correlation is calculated using Fishers' transformation
##corAverage should be similar to corFishers
corFishers<-corPerFirm[, lapply (.SD, function(x) fisherz(x)), .SDcols=cols, by=.(code, rowname)] #apply Fishers' transformation and calculate Fishers' z
corFishers<-corFishers[, lapply(.SD, mean, na.rm=TRUE), by=rowname, .SDcols=cols]# calculate average per each combination of variables!
corFishers<-corFishers[,lapply(.SD, fisherz2r), .SDcols=cols, by=rowname]
write.csv(corFishers, file="corFishers.csv")

#------------------------------------
#Transition matrix preparation 

#Calculate Medians for visibility variables - as an alternative for cluster analysis
colsVis<-colnames(dataL[,c("PressAll",
                        "PressWires",
                        "PressPapers",
                        "PressPapersMajor",  
                        "PressWiresMajor", 
                        "EPS1NE",
                        "AnnOwnSensitive", 
                        "AnnOwn",
                        "transactions",
                        "volume",
                        "turnover",
                        "SVI_ASX",
                        "SVI_AU",
                        "SVI_NEW"), with=F])
dataR<-data.table(dataR)
visibilityData<-dataR[, .SD, .SDcols=colsVis, by=.(code, date)]
setkey(visibilityData, date, code)

visibilityMedian<-visibilityData[, lapply(.SD, function (x) median(x[x!=0])), .SDcols=colsVis, by=date]
setkey(visibilityMedian, date)


visibilityT<-visibilityData[, .(code, date)]
visibilityMedian<-merge(visibilityT, visibilityMedian, by="date", all.X=TRUE)
setkey(visibilityMedian, date, code)


#visibilityT<-merge(visibilityData, visibilityMedian, by="date", all.X=TRUE, suffixes=c(".normal", ".median"))
test2<-ifelse(visibilityData[,c(-1,-2)]==0, 0, ifelse(visibilityData[,c(-1,-2)]<visibilityMedian[,c(-1,-2)], 1, 2))
visibilityT<-cbind(test2, visibilityT)

rm(test2, visibilityData, visibilityMedian)

#TRANSITION MATRIX

##transition matrix for dual states
trans.matrix_full(dataL, "PressAllD", TRUE) # with probabilities
trans.matrix_full(dataL, "PressPapersD", TRUE) # with probabilities
trans.matrix_full(dataL, "PressWiresD", TRUE) # with probabilities
trans.matrix_full(dataL, "AnnOwnD", TRUE) # with probabilities
#SVI_NEW dual
test<-dataL[, .(code, date, SVI_NEW)]
test$SVI_NEWD<-ifelse(test$SVI_NEW>0, 1, 0)
test$SVI_NEW<-NULL
trans.matrix_full(test, "SVI_NEWD", TRUE) # with probabilities
#transition matrix on median

#calculate medians for press (do for all of them and then do the t-test to see the difference)
#SVI_new and SVI_AU and do t-test for them as well
#EPS1NE
#visibilityT - is the dataset for median split groups
trans.matrix_full(visibilityT, "PressAll", TRUE)
trans.matrix_full(visibilityT, "PressPapers", TRUE)
trans.matrix_full(visibilityT, "PressPapersMajor", TRUE)
trans.matrix_full(visibilityT, "PressWires", TRUE)
trans.matrix_full(visibilityT, "PressWiresMajor", TRUE)
trans.matrix_full(visibilityT, "AnnOwn", TRUE)
trans.matrix_full(visibilityT, "AnnOwnSensitive", TRUE)
trans.matrix_full(visibilityT, "SVI_ASX", TRUE)
trans.matrix_full(visibilityT, "SVI_AU", TRUE)
trans.matrix_full(visibilityT, "SVI_NEW", TRUE)

##### THIS NEEDS TO WORK---------------------------
#autocorrelations
test<-subset(dataR, dataR$code=="3PL", select =cols) 

t<-xts(test$lSVI_new, test$date)                                                 
tt<-acf(t, type="correlation")
tt

rm(NonZeros, NonZerosMont, NonZeroMonthMeansh, obsPerYear, code.length, VTest)

rm(vPerFirmPerYearMean, vPerFirmPerYearMedian, vIndustry, vCoveragePcY, vASX100Pc, vASX200Pc, corAverageZ, corPerFirm, corPerFirmFishers, corPerFirmPerYear, allC, allD, obsPerYear) #to be removed last line in the module