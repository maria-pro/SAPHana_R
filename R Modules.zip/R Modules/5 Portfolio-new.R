#TO DO: at the moment prices include prices for the current month -> return is calculated for the current month as well.
#return needs to be led (current month = month +1 return for prediction purposes) (you can LAG xts, but lead does not work)
#Univariate test - at this stage only MarketCap is done, needs to be done for Book-to-Market and past 12 month momentum (have no idea what it is)


#it generates the following additional datasets

#prices: large xts with monthly returns (index 01-01-2016) (1)
#returns: xts with monthly returns (index 01-01-2016) (2)
#signal: xts with monthly signals (comparison of ClusterMeans with 0)
#w: xts with weights for portfolio: equal weights for all signal=True (clusterMeans=0)
#returnsAllOrd: xts with monthly returns for AllOrdinary (index 01-01-2016) (3)
#riskFree: xts with monthly returns for riskFree asset (from datastream) 4)

#f: Fama-French factors for Austra-Asia



#need to test portfolio strategy

#alternative risk free is Australia 90-day Australian Bank from Quandl ?
#CALCULATE Prior year return
#BETA - DO I REALLY NEED THIS???? or only portfolio beta

#function to calculate monthly returns with days stipped of (month-year format) but days are needed since everything else is in the other format
r<-function(x) {m<-to.monthly(x[,6])[,4];diff(m)/lag(m)}

require(quantmod)
require(PerformanceAnalytics)
require(reshape)
require(lubridate)
require(Quandl) #free data repository! fama-french factors
require(quantmod)

#(1) download prices from yahoo in the global environment but do NOT create new variables
symbols<-as.character(unique(dataL$code))
symbols<-paste(symbols, "AX", sep=".")
#use closing prices (unadjasted) - it is possible to use adjustOHLC function to adjust prices later
#stockData is a large list
stockData <- lapply(symbols,function(x) Cl(getSymbols(x,auto.assign=FALSE, src='yahoo', from = '2000-01-01'))) #Stock_Data is all prices info
#prices is a large xts 
prices <- do.call(cbind, stockData) # this is a large xts 
colnames(prices)<- as.character(unique(dataL$code))

#(2) calculate monthly returns
returns <- lapply(stockData,function(x) monthlyReturn(x)) #if prices are used, they include lots of NAs due to out-of-bound listing period dates
returns <- lapply(returns,
                  function(x) {
                    index(x) <- floor_date(index(x), "month")
                    # Or if you want to round to end of month change to:
                    # index(x) <- ceiling_date(index(x), "month")
                    x
                  })
#returns is a large xts 
returns <- do.call(merge, returns) #merge the list
colnames(returns) <- as.character(unique(dataL$code))

#need to lead prices up one month
returnsDT<-lapply(returns, function (x) lag(x, -1))

##add monthly returns to data set
returnsDT<-as.data.table(returns, keep.rownames=TRUE) #convert xts into a datatable
returnsDT<- melt(returnsDT, id="index")  #converts datatable into a vector: index, firm, return
colnames(returnsDT)<-c("date", "code", "returnYahoo")
setkey(returnsDT, code, date)
dataP<-dataL
dataP<-merge(dataP, returnsDT, by=c("code", "date"), all.x=TRUE)#merge returns2 with dataL
rm(returnsDT) #remove temporary variable

#(3)download AllOrdinaries
getSymbols("^AORD", src='yahoo', from = '2000-01-01-01', auto.assign=TRUE) #AORD
returnsAllOrd<-monthlyReturn(Ad(AORD)) #monthly return for AllOrdinaries
index(returnsAllOrd) <- floor_date(index(returnsAllOrd), "month")  #adjust the end-date for month to the beginning of the month
returnsAllOrdDT<-as.data.table(returnsAllOrd, keep.rownames=TRUE)
colnames(returnsAllOrdDT)<-c("date", "returnsAllOrd")
setkey(returnsAllOrdDT, date)
dataP<-merge(dataP, returnsAllOrdDT, by="date", all.x=TRUE) #add AllOrd return to the dataset
rm(AORD, returnsAllOrdDT) #remove temporary variable

#(4)download riskFree 
riskFree<-data.table(read.csv("RiskFree.csv", col.names=c("date", "riskFree")))
riskFree$date=as.Date(riskFree$date, format="%d/%m/%Y")
setkey(riskFree, date)
dataP<-merge(dataP, riskFree, by="date", all.x=TRUE) #add AllOrd return to the dataset
#transfer data.table into xts
riskFree<-as.xts.data.table (riskFree)

#CALCULATE AVERAGE CLOSING PRICE FOR THE MONTH
#pricesClose <- do.call(cbind,lapply(stockData, Cl)) #prices now includes only closing prices, this step is not needed
#colnames(pricesClose) <- as.character(unique(dataL$code))

pricesClose <- as.data.table(prices, keep.rownames=TRUE) 
#this below step is not needed if only close prices are kept in prices
#pricesClose <- as.data.table(pricesClose, keep.rownames=TRUE) #convert list to data table and keep dates as index
pricesClose<- melt(pricesClose, id="index")  #converts vector into datatable into a vector: index, firm, return
colnames(pricesClose)<-c("date", "code", "pricesClose")

pricesClose<-pricesClose[, .(date, code, pricesClose, dateShort=format(date,  "%Y-%m"))]#create a new column with short date format

pricesClose<-pricesClose[, .(date, pricesClose=mean(pricesClose, na.rm=TRUE)), by=.(dateShort, code)]
setkey(pricesClose, date, code)
dataP<-merge(dataP, pricesClose, by=c("date","code"), all.x=TRUE) #but how does this merge on date if dateShort????
rm(pricesClose)


#calculate yearly return and lagged it
returnsLastYr <- lapply(stockData,function(x) yearlyReturn(x)) #if prices are used, they include lots of NAs due to out-of-bound listing period dates
returnsLastYr <- lapply(returnsLastYr,
                  function(x) {
                    index(x) <- floor_date(index(x), "year")
                    # Or if you want to round to end of month change to:
                    # index(x) <- ceiling_date(index(x), "month")
                    x
                  })
#returns is a large xts 
returnsLastYr<-lapply(returnsLastYr, function (x) lag(x))

returnsLastYr <- do.call(merge, returnsLastYr) #merge the list

#need to populate observations across the whole year
test<-xts(x=seq(from=1, to=length(index(returns))),index(returns))
returnsLastYr <- merge.xts(test, returnsLastYr,fill=na.locf)
returnsLastYr$test<-NULL 
colnames(returnsLastYr) <- as.character(unique(dataL$code))
returnsLastYr <- as.data.table(returnsLastYr, keep.rownames=TRUE) 
returnsLastYr<- melt(returnsLastYr, id="index")
colnames(returnsLastYr)<-c("date", "code", "returnsLastYr")
dataP<-merge(dataP, returnsLastYr, by=c("date","code"), all.x=TRUE) 
rm(test, returnsLastYr)

#------Univariate test------ THIS NEEDS MORE WORK AND MORE ELEGANT SOLUTIONS
#NEED TO KNOW HOW MANY GROUPS TO HOLD
#------------------------------------

#they do it every month
#take all stock and sort it into 3 (or 4 or 5) subgroups (terciles) according to size 

#-----size and visibility-----
dataP<-dataP[, GroupMarketCap:=ntile(MarketCap, 3), by=date]
testGroupsMarketCap<-dataP[, .N, by=.(GroupMarketCap, date)] # see number of obs in each group by date
#sort within the subgroup into -no coverage, low coverage, high coverage (=portfolios)
testGroupsVisMarketCap<-dataP[, .N, by=.(date, GroupMarketCap, ClusterKMeans)]
#calculate equal-weighted return of each portfolio for the following months and compare between No -High visibility
#-------Portfolio return on clusters/size groups
portfolioReturnMarketCap<-dataP[, mean(returnYahoo, na.rm=TRUE), by=.(date, ClusterKMeans, GroupMarketCap)]
#calculate average return for each portfolio within each subgroup across all months
portfolioReturnTotalMarketCap<-dataP[, mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, GroupMarketCap)]

#-------------------------------------------- -
#ClusterKMeans = 2, Group 1 shows Inf - NEED TO INVESTIGATE


#calculate the difference between average monthly returns between No-High portfolios for each subgoup
#--------TO DO!!!!!
# NEEDS TO BE DONE portfolioReturn<-dataP[, mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, Group)]

#do t-test for portfolio returns between No-High portfolios for each subgroup level
portfolioReturnTTest<-dataP[, returnYahooAvr:= mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, GroupMarketCap)]
test<-portfolioReturnTotal[(ClusterKMeans==1) | (ClusterKMeans==4), ]
#--------TO DO!!!!!
t.test(V1 ~ ClusterKMeans, test) #THIS NEEDS TO BE DONE MORE ELEGANTLY 


#------Multivariate tests

##1. form long-short portfolios of stock sorted by media coverage
###for each month divide the stock into no-media, low media, high media groups - done already
#ClusterKMeans - cluster on visibility

##2 compute the return in the following months on a zero investment portfolio that longs the stock with no media coverage and shorts the stocks with high media coverage.
#for a strategy you need: 1.stock data (=returns) 2. signal (=Visibility = clusters) 3. weights (= % of the portfolio)

#returns= XTS with monthly returns (calculated earlier)
##signal = visibility clustering 
clusterXTS<- dataP[, .(date, code, ClusterKMeans)]
#code cannot be stored in the xts, so codes need to be changed into columns
clusterXTS<-as.xts.data.table(dcast(data = clusterXTS,formula = date~code,fun.aggregate = sum,value.var = "ClusterKMeans"))

signal<-clusterXTS==0 #timestamp is the first day of the month: 2004-01-01

# 3 weights
#weights are the same as portfolios are equal weighted
w <- signal/(rowSums(signal, na.rm=TRUE)+1e-16) # equal weights
w$zeroes <- 1 - rowSums(w, na.rm=TRUE)
returns$zeroes <- 0

##3. Repeat this every month to form a time series of returns for this zero-investment portfolio
returns2<-returns["2004/"]
# rebalanced portfolio
portfolio.rebal <-Return.portfolio(returns2,
                                   rebalance_on="months",
                                   weights=w,wealth.index=TRUE,verbose=TRUE)


# buy and hold portfolio/no rebalancing
portfolio.bh <-Return.portfolio(returns2,
                                weights=w,wealth.index=TRUE,verbose=TRUE)

portfolios.2 <-cbind(portfolio.rebal$returns,portfolio.bh$returns)
colnames(portfolios.2) <-c("rebalanced","buy and hold")

#------this part is for regression -----

#download Fama-French factors

# use Quandl Kenneth French Fama/French factors
# http://www.quandl.com/KFRENCH/FACTORS_D

f <- Quandl(
  "KFRENCH/FACTORS_D"
)

f <- as.xts(f[,-1],order.by=f[,1])

plot.zoo( f, main = NA )
mtext(
  text = "Fama/French Factors from Quandl"
  , adj = 0
  , outer = T
  , line = -2
  , cex = 2
)

##4.  Time series of returns are regressed on factors:
##  Fama-French 3 factor
##Carhart 4 factor
##Pastor-Stambaugh 5 factor

##5. look at alpha in the model: if it is insignificant then the return difference between no-coverage and high coverage is fully explained by known factors

##6. If alpha decreses when factors are added then the factor models do explain a significant portion of the premium.

##basic points per month is just a simple difference in coefficient
