require(foreign)
require (nloptr)
require(plm)
require(lmtest)

fpm <- plm(VisibilityClusterMain ~ lAnnOwn + RnD, dataR, model='pooling', index=c('code', 'date'))
fpmg <- pmg(VisibilityClusterMain ~ lAnnOwn + RnD, dataR, index=c("date","code")) ##Fama-MacBeth

#standard errors manipulations
##1. Newey-West 
fpmg.coefficients <- fpmg$ 
fpmg.coefficients
coeftest(fpmg)
#creating the estimator
the.years <- unique(test$year)
a.formula <- y ~ x


first.step <-  lapply(the.years, function(a.year) {
  temp.data <- test[test$year == a.year, ]
  an.lm <- lm(a.formula, data = temp.data)
  the.coefficients <- an.lm$coef
  the.results <- as.data.frame(cbind(a.year, t(the.coefficients)))
  the.results
}) 

first.step.df <- do.call('rbind', first.step)

second.step.coefficients <- apply(first.step.df[, -1], 2, mean)
second.step.coefficients

identical(fpmg.coefficients, second.step.coefficients)

#Check that they are identical both ways just in case. 
#Last, you can obtain the Newey-West (1987) with one lag adjusted t-statistics for the means with:
  
 second.step.NW.sigma.sq <- apply(first.step.df[, -1], 2, 
                                   function(x) sqrt(NeweyWest(lm(x ~ 1), 
                                                              lag = 1, prewhite = FALSE)['(Intercept)',       
                                                                                         '(Intercept)']))
t.statistics.NW.lag.1 <- second.step.coefficients / second.step.NW.sigma.sq

t.statistics.NW.lag.1


##Double-clustering formula (Thompson, 2011)
vcovDC <- function(x, ...){
  vcovHC(x, cluster="group", ...) + vcovHC(x, cluster="time", ...) -     vcovHC(x, method="white1", ...)
}

##OLS, White and clustering
coeftest(fpm)

#t test of coefficients:
#Estimate Std. Error t value Pr(>|t|)    
#(Intercept) 0.029680   0.028359  1.0466   0.2954    
#x           1.034833   0.028583 36.2041   <2e-16 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

coeftest(fpm, vcov=function(x) vcovHC(x, method="white1", type="HC1"))

#t test of coefficients:
#Estimate Std. Error t value Pr(>|t|)    
#(Intercept) 0.029680   0.028361  1.0465   0.2954    
#x           1.034833   0.028395 36.4440   <2e-16 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

coeftest(fpm, vcov=function(x) vcovHC(x, cluster="group", type="HC1"))

#t test of coefficients:
#Estimate Std. Error t value Pr(>|t|)    
#(Intercept) 0.029680   0.066952  0.4433   0.6576    
#x           1.034833   0.050550 20.4714   <2e-16 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 
#

coeftest(fpm, vcov=function(x) vcovHC(x, cluster="time", type="HC1"))

#t test of coefficients:
#  
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept) 0.029680   0.022189  1.3376   0.1811    
#x           1.034833   0.031679 32.6666   <2e-16 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

coeftest(fpm, vcov=function(x) vcovDC(x, type="HC1"))

#t test of coefficients:
#Estimate Std. Error t value Pr(>|t|)    
#(Intercept) 0.029680   0.064580  0.4596   0.6458    
#x           1.034833   0.052465 19.7243   <2e-16 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 