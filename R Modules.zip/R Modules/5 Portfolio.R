#need to test portfolio strategy

#to DO - recalculate return
##2. calculate prices from Dima's file (use the same code as 1)
#CALCULATE Prior year return
#BETA - DO I REALLY NEED THIS???? or only portfolio beta



#function to calculate monthly returns with days stipped of (month-year format)
r<-function(x) {m<-to.monthly(x[,6])[,4];diff(m)/lag(m)}


#take all stock and sort it into 3 (or 4 or 5) subgroups (terciles) according to size
#sort within the subgroup into -no coverage, low coverage, high coverage (=portfolios)
#calculate equal-weighted return of each portfolio for the following months and tabulate it....



require(PerformanceAnalytics)
require(reshape)
require(lubridate)
library(Quandl) #free data repository! fama-french factors
library(quantmod)

#require(TTR)

#lm.MMM<- lm(MMM ~ SP500,df) #calculates beta for MMM stock

#download prices from yahoo in the global environment but do NOT create new variables
symbols<-as.character(unique(dataL$code))
symbols<-paste(symbols, "AX", sep=".")
#use closing prices (unadjasted) - it is possible to use adjustOHLC function to adjust prices later
#stockData is a large list
stockData <- lapply(symbols,function(x) Cl(getSymbols(x,auto.assign=FALSE, src='yahoo', from = '2000-01-01'))) #Stock_Data is all prices info
#prices is a large xts 
prices <- do.call(cbind, stockData) # this is a large xts 

#test<-as.data.table(prices, keep.rownames=TRUE)

#write.csv(data.frame(prices), file="stockData.csv", row.names=TRUE) # does not work - shows missing data in row.names
#returns <- lapply(stockData,function(x) monthlyReturn(Ad(x))) # thisis if to use ALL prices in stockData (without Cl)
returns <- lapply(stockData,function(x) monthlyReturn(x))
#test<-lapply(prices, function(x) to.monthly(x))
#test2<-do.call(cbind, test)



#returns<-to.monthly([,6])[,4];diff(m)/lag(m)

#need to update the index as it shows different end-of-month dates
returns <- lapply(returns,
                          function(x) {
                            index(x) <- floor_date(index(x), "month")
                            # Or if you want to round to end of month change to:
                            # index(x) <- ceiling_date(index(x), "month")
                            x
                          })
returns <- do.call(merge, returns) #merge the list
colnames(returns) <- as.character(unique(dataL$code)) #change column names into firm names

returnsDT<-as.data.table(returns, keep.rownames=TRUE) #convert xts into a datatable
returnsDT<- melt(returnsDT, id="index")  #converts datatable into a vector: index, firm, return
colnames(returnsDT)<-c("date", "code", "returnYahoo")
setkey(returnsDT, code, date)
dataP<-dataL

#PCH<-dataL[, .(code, date, MarketCap, ClusterKMeans)]
dataP<-merge(dataP, returnsDT, by=c("code", "date"), all.x=TRUE)#merge returns2 with dataL
#test<-dataP[, sum(is.na(returnYahoo)), by=code] #missing values

##download AllOrdinaries
getSymbols("^AORD", src='yahoo', from = '2000-01-01-01', auto.assign=TRUE) #AORD
returnsAllOrd<-monthlyReturn(Ad(AORD)) #monthly return for AllOrdinaries
index(returnsAllOrd) <- floor_date(index(returnsAllOrd), "month")  #adjust the end-date for month to the beginning of the month
returnsAllOrdDT<-as.data.table(returnsAllOrd, keep.rownames=TRUE)
colnames(returnsAllOrdDT)<-c("date", "returnsAllOrd")
setkey(returnsAllOrdDT, date)
dataP<-merge(dataP, returnsAllOrdDT, by="date", all.x=TRUE) #add AllOrd return to the dataset

rm(AORD, returnsAllOrdDT)

##download riskFree
riskFree<-data.table(read.csv("RiskFree.csv", col.names=c("date", "riskFree")))
riskFree$date=as.Date(riskFree$date, format="%d/%m/%Y")
setkey(riskFree, date)
dataP<-merge(dataP, riskFree, by="date", all.x=TRUE) #add AllOrd return to the dataset
rm(riskFree)



#alternative solution
###Stocks = lapply(Symbols, function(sym) {dailyReturn(na.omit(getSymbols(sym, from=StartDate, auto.assign=FALSE)))})
#do.call(merge, Stocks)


#---------------try with PCH datastream to see if it has less missing values

#dataAdd<-read.csv("PCH.csv")
#dataAdd$date=as.Date(dataAdd$date, format="%d/%m/%Y")
#test <- data.table(melt(dataAdd, id="date")) #converts the dataframe into a vector repeating column names(Firm names) and values (Return)
#colnames(test)<-c("date", "code", "RetDatastream")
#setkey(test, code, date)

#dataP<-merge(dataP, test, by=c("date","code"), all.x=TRUE)
#rm(test)

#rm(symbols, stockData)

#CALCULATE AVERAGE CLOSING PRICE FOR THE MONTH
#pricesClose <- do.call(cbind,lapply(stockData, Cl)) #prices now includes only closing prices, this step is not needed
#colnames(pricesClose) <- as.character(unique(dataL$code))
colnames(prices)<- as.character(unique(dataL$code))

pricesClose <- as.data.table(prices, keep.rownames=TRUE) 
#this below step is not needed if only close prices are kept in prices
#pricesClose <- as.data.table(pricesClose, keep.rownames=TRUE) #convert list to data table and keep dates as index
pricesClose<- melt(pricesClose, id="index")  #converts vector into datatable into a vector: index, firm, return
colnames(pricesClose)<-c("date", "code", "pricesClose")

pricesClose<-pricesClose[, .(date, code, pricesClose, dateShort=format(date,  "%Y-%m"))]#create a new column with short date format

pricesClose<-pricesClose[, .(date, pricesClose=mean(pricesClose, na.rm=TRUE)), by=.(dateShort, code)]
setkey(pricesClose, date, code)
dataP<-merge(dataP, pricesClose, by=c("date","code"), all.x=TRUE)
rm(pricesClose)

#CALCULATE Prior year return - THIS NEEDS TO BE CHECKED FIRST



#STOPPED HERE



#------Univariate test------
#they do it every month
#-----size and visibility-----

#take all stock and sort it into 3 (or 4 or 5) subgroups (terciles) according to size
dataP<-dataP[, Group:=ntile(MarketCap, 3), by=date]
testGroups<-dataP[, .N, by=.(Group, date)] # see number of obs in each group by date
#sort within the subgroup into -no coverage, low coverage, high coverage (=portfolios)
testGroupsVis<-dataP[, .N, by=.(date, Group, ClusterKMeans)]
#calculate equal-weighted return of each portfolio for the following months and compare between No -High visibility
#-------Portfolio return on clusters/size groups
portfolioReturn<-dataP[, mean(returnYahoo, na.rm=TRUE), by=.(date, ClusterKMeans, Group)]
#calculate average return for each portfolio within each subgroup across all months
portfolioReturnTotal<-dataP[, mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, Group)]

#-------------------------------------------- -
#ClusterKMeans = 2, Group 1 shows Inf - NEED TO INVESTIGATE


#calculate the difference between average monthly returns between No-High portfolios for each subgoup
#--------TO DO!!!!!
# NEEDS TO BE DONE portfolioReturn<-dataP[, mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, Group)]

#do t-test for portfolio returns between No-High portfolios for each subgroup level
portfolioReturnTTest<-dataP[, returnYahooAvr:= mean(returnYahoo, na.rm=TRUE), by =.(ClusterKMeans, Group)]
test<-portfolioReturnTotal[(ClusterKMeans==1) | (ClusterKMeans==4), ]
#--------TO DO!!!!!
t.test(V1 ~ ClusterKMeans, test) #THIS NEEDS TO BE DONE MORE ELEGANTLY 
#--------TO DO!!!!!


#------Multivariate tests

##1. form long-short portfolios of stock sorted by media coverage
###for each month divide the stock into no-media, low media, high media groups - done already
#ClusterKMeans - cluster on visibility

##2 compute the return in the following months on a zero investment portfolio that longs the stock with no media coverage and shorts the stocks with high media coverage.
#for a strategy you need: 1.stock data (=returns) 2. signal (=Visibility = clusters) 3. weights (= % of the portfolio)
#returns= XTS with monthly returns
##signal = visibility clustering 
clusterXTS<- dataP[, .(date, code, ClusterKMeans)]
#code cannot be stored in the xts, so codes need to be changed into columns
clusterXTS<-as.xts.data.table(dcast(data = clusterXTS,formula = date~code,fun.aggregate = sum,value.var = "ClusterKMeans"))

#signal <- prices > xts(apply(prices, 2, SMA, n = 200, na.rm=TRUE), order.by=index(prices))
#signal <- prices > xts(rollapply(prices, 200, mean, na.rm=TRUE))



# 3 weights
#weights are the same as portfolios are equal weighted

##3. Repeat this every month to form a time series of returns for this zero-investment portfolio



##4.  Time series of returns are regressed on factors:
##  Fama-French 3 factor
##Carhart 4 factor
##Pastor-Stambaugh 5 factor

##5. look at alpha in the model: if it is insignificant then the return difference between no-coverage and high coverage is fully explained by known factors

##6. If alpha decreses when factors are added then the factor models do explain a significant portion of the premium.

##basic points per month is just a simple difference in coefficient


#step 1: download prices
#symbols<-as.character(unique(dataL$code)) #downloading in the gloval environment  
#symbols<-paste(symbols, "AX", sep=".")
#getSymbols(symbols, src='yahoo', from = '2000-01-01-01', auto.assign=FALSE) #creates separate variable for each company with Yahoo price data 

#prices <- list()
#for(i in 1:length(symbols)) {
#  tmp <- Ad(get(symbols[[i]])) #extract adjusted price from each firm dataframe with prices
#  prices[[i]] <- tmp
#}
#prices <- do.call(cbind, prices)

#step 2: create signal that triggers investing - visibility

# Our signal is a simple adjusted price over 200 day SMA - signal that triggers investing
#signal <- prices > xts(apply(prices, 2, SMA, n = 200, na.rm=TRUE), order.by=index(prices))
signal <- prices > xts(rollapply(prices, 200, mean, na.rm=TRUE))

# equal weight all assets with price above SMA200
returns <- Return.calculate(prices)
weights <- signal/(rowSums(signal, na.rm=TRUE)+1e-16)

# With Return.portfolio, need all weights to sum to 1
weights$zeroes <- 1 - rowSums(weights, na.rm=TRUE)
returns$zeroes <- 0

monthlyWeights <- na.omit(weights[endpoints(weights, on = 'months'),])
weights <- na.omit(weights)
returns <- na.omit(returns)

out <- Return.portfolio(R = returns, weights = monthlyWeights, rebalancing_on="months")
beginWeights <- out$BOP.Weight
endWeights <- out$EOP.Weight
txns <- beginWeights - lag(endWeights)
monthlyTO <- xts(rowSums(abs(txns[,1:9])), order.by=index(txns))
plot(monthlyTO)


#------this part is for regression -----

#download Fama-French factors

# use Quandl Kenneth French Fama/French factors
# http://www.quandl.com/KFRENCH/FACTORS_D



f <- Quandl(
  "KFRENCH/FACTORS_D"
)

f <- as.xts(f[,-1],order.by=f[,1])

plot.zoo( f, main = NA )
mtext(
  text = "Fama/French Factors from Quandl"
  , adj = 0
  , outer = T
  , line = -2
  , cex = 2
)

